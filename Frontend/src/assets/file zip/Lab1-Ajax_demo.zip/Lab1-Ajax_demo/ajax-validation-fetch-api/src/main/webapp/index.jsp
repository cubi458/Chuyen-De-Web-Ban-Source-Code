<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<script type="text/javascript">
	// 
    document.addEventListener("DOMContentLoaded", function() {
        // Vô hiệu hóa nút submit khi tải trang
        document.getElementById('submit_btn').disabled = true;

        // Bộ xử lý sự kiện cho sự kiện keyup trên trường nhập liệu userid
        document.getElementById('userid').addEventListener('keyup', function() {
        	validateUserId();
    	});
    });
	
	// Hàm kiểm tra tính hợp lệ của userid dùng fetch API 
    function validateUserId() {
    	var userId = document.getElementById('userid').value;
        var url = "validate?id=" + encodeURIComponent(userId);

        // Sử dụng fetch API
        fetch(url)
        .then( response => response.text() )
        .then( responseXML => { processRequest(responseXML); } );
     }
	
    // Hàm kiểm tra tính hợp lệ của userid sử dụng async/await
    async function validateUserId1() {
    	var userId = document.getElementById('userid').value;
        var url = "validate?id=" + encodeURIComponent(userId);

        try {
        	let response = await fetch(url);
            let responseXML = await response.text();
            processRequest(responseXML);
        } catch (error) {
        	console.error('Error:', error);
        }
    }
    
    function processRequest(responseXML) {
    	var parser = new DOMParser();
        var xmlDoc = parser.parseFromString(responseXML, "text/xml");
        var message = xmlDoc.getElementsByTagName("valid")[0].childNodes[0].nodeValue;

        // Gọi hàm "setMessageUsingInline" để hiển thị thông báo
        setMessageUsingInline(message);

        // Kích hoạt hoặc vô hiệu hóa nút submit dựa trên kết quả kiểm tra tính hợp lệ
        document.getElementById('submit_btn').disabled = (message === "false");
    }

    // Hàm hiển thị thông báo dựa trên kết quả kiểm tra tính hợp lệ
    function setMessageUsingInline(message) {
    	var userIdMessage = document.getElementById('userIdMessage');
    	if (message === "false") {
        	userIdMessage.innerHTML = '<div style="color:red">Invalid User Id</div>';
        } else {
        	userIdMessage.innerHTML = '<div style="color:green">Valid User Id</div>';
        }
    }
</script>
<title>Form Data Validation using Fetch and Promise</title>
</head>
<body>
	<h1>Form Data Validation using Fetch and Promise</h1>
	<hr />
	<p>Check the registered username using fetch and Promise</p>

	<form name="updateAccount" action="validate" method="post">
		<input type="hidden" name="action" value="create" />
		<table border="0" cellpadding="5" cellspacing="0">
			<tr>
				<td><b>User Id:</b></td>
				<td>
					<!-- Trường nhập liệu với id là "userid" 
					và hàm "validateUserId()" được liên kết với sự kiện onkeyup -->
					<input type="text" size="20" id="userid" name="id">
				</td>
				<!-- Phần tử div "userIdMessage" thông báo kiểm tra tính hợp lệ sẽ được hiển thị -->
				<td>
					<div id="userIdMessage"></div>
				</td>
			</tr>
			<tr>
				<td align="right" colspan="2"><input id="submit_btn"
					type="submit" value="Create Account"></td>
				<td></td>
			</tr>
		</table>
	</form>
</body>
</html>
