var req;
var target;
var isIE;

// (3) JavaScript function in which XMLHttpRequest JavaScript object is created.
// Please note that depending on a browser type, you create
// XMLHttpRequest JavaScript object differently.  Also the "url" parameter is not
// used in this code (just in case you are wondering why it is
// passed as a parameter).
//
function initRequest(url) {
	if (window.XMLHttpRequest) {
		req = new XMLHttpRequest();
	} else if (window.ActiveXObject) {
		isIE = true;
		req = new ActiveXObject("Microsoft.XMLHTTP");
	}
}

// (2) Event handler that gets invoked whenever a user types a character
// in the input form field whose id is set as "userid".  This event
// handler invokes "initRequest(url)" function above to create XMLHttpRequest
// JavaScript object.
//
function validateUserId() {
	if (!target) target = document.getElementById("userid");
	var url = "validate?id=" + escape(target.value);

	// Invoke initRequest(url) to create XMLHttpRequest object
	initRequest(url);

	// The "processRequest" function is set as a callback function.
	// (Please note that, in JavaScript, functions are first-class objects: they
	// can be passed around as objects.  This is different from the way
	// methods are treated in Java programming language.)
	req.onreadystatechange = processRequest;
	req.open("GET", url, true);
	req.send(null);
}

// (4) Callback function that gets invoked asynchronously by the browser
// when the data has been successfully returned from the server.
// (Actually this callback function gets called every time the value
// of "readyState" field of the XMLHttpRequest object gets changed.)
// This callback function needs to be set to the "onreadystatechange"
// field of the XMLHttpRequest.
//
function processRequest() {
	if (req.readyState == 4) {
		if (req.status == 200) {

			// Extract "true" or "false" from the returned data from the server.
			// The req.responseXML should contain either <valid>true</valid> or <valid>false</valid>
			var message = req.responseXML.getElementsByTagName("valid")[0].childNodes[0].nodeValue;

			// Call "setMessageUsingDOM(message)" function to display
			// "Valid User Id" or "Invalid User Id" message.
			setMessageUsingInline(message);

			// If the user entered value is not valid, do not allow the user to
			// click submit button.
			var submitBtn = document.getElementById("submit_btn");
			if (message == "false") {
				submitBtn.disabled = true;
			} else {
				submitBtn.disabled = false;
			}
		}
	}
}

// This function is not used for now. You will use this later.
//
function setMessageUsingInline(message) {
	mdiv = document.getElementById("userIdMessage");
	if (message == "false") {
		mdiv.innerHTML = "<div style=\"color:red\">Invalid User Id</div>";
	} else {
		mdiv.innerHTML = "<div style=\"color:green\">Valid User Id</div>";
	}
}

// (5) Function in which message indicating the validity of the data gets displayed
// through the "userIdMessage" <div> element.
//
function setMessageUsingDOM(message) {
	var userMessageElement = document.getElementById("userIdMessage");
	var messageText;
	if (message == "false") {
		userMessageElement.style.color = "red";
		messageText = "Invalid User Id";
	} else {
		userMessageElement.style.color = "green";
		messageText = "Valid User Id";
	}

	userMessageElement.innerHTML = messageText;
}

function disableSubmitBtn() {
	var submitBtn = document.getElementById("submit_btn");
	submitBtn.disabled = true;
}